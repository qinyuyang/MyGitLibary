/*    */ package com.googlecode.javacpp;
/*    */ 
/*    */ public abstract class FunctionPointer extends Pointer
/*    */ {
/*    */   protected FunctionPointer()
/*    */   {
/*    */   }
/*    */ 
/*    */   protected FunctionPointer(Pointer p)
/*    */   {
/* 46 */     super(p);
/*    */   }
/*    */ }

/* Location:           E:\androidOpenLibrary\VideoRecorder-master\VideoRecorder-master\libs\javacpp.jar
 * Qualified Name:     com.googlecode.javacpp.FunctionPointer
 * JD-Core Version:    0.6.2
 */